
  # HRMS Web Application Screens

  This is a code bundle for HRMS Web Application Screens. The original project is available at https://www.figma.com/design/f5t0IlzzKnHpB1335HlQZ8/HRMS-Web-Application-Screens.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  